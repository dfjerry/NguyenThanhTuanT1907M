/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Day3;

/**
 *
 * @author Admin
 */
public class Account {
    private final int accountID;
    private final String holderName;
    private final String accountType;
    {
        accountID = 100;
        holderName = "Tuan Thanh";
        accountType = "Savings";
    }
    public static void main(String[] args) {
        System.out.println("account details");
        System.out.println("=========");
        System.out.println("id: " + accountID + "Type" + accountType);
        Account objAccount = new Account();
        objAccount.displayAccountDetails();
    }
}
