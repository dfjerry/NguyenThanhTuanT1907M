/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Array;

/**
 *
 * @author Admin
 */
public class Ass4 {
    public static void main(String[] args) {
        new Ass3().methodPublic();
        new Ass3().methodProtected();
        new Ass3().methodDefault();
    }
    public void methodPublic(){
        
    }
    protected void methodProtected(){
        
    }
    void  methodDefault(){
        
    }
    private void methodPrivate(){
        
    }
}
